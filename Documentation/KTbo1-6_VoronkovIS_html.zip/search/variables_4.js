var searchData=
[
  ['palette_89',['palette',['../structbmp_file.html#a660c6ff33047739b21394c989b038a9c',1,'bmpFile']]],
  ['planes_90',['Planes',['../structbmih.html#a34e6801cd89e911c85525a0ed2128f1e',1,'bmih']]]
];
