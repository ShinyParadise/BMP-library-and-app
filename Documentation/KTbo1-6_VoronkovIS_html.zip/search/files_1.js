var searchData=
[
  ['downscale_2ecpp_59',['downscale.cpp',['../downscale_8cpp.html',1,'']]],
  ['downscale_2eh_60',['downscale.h',['../downscale_8h.html',1,'']]]
];
