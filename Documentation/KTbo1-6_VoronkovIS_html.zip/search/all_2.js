var searchData=
[
  ['clrimportant_13',['ClrImportant',['../structbmih.html#a6ced1f6898b2634e3c00a8c5ddb7a2b7',1,'bmih']]],
  ['clrused_14',['ClrUsed',['../structbmih.html#ad203d5da06f0b6b39b6d7be8d4ee37e9',1,'bmih']]],
  ['compression_15',['Compression',['../structbmih.html#abc9a891fbcf267af4bd088e247aac0cf',1,'bmih']]]
];
