var searchData=
[
  ['scan_97',['scan',['../structbmp_file.html#a8753c06fd3d4ca736b97bea2e0931723',1,'bmpFile']]],
  ['sizeimage_98',['SizeImage',['../structbmih.html#a7676c1fdc4d75a1c35b60656570e3509',1,'bmih']]]
];
