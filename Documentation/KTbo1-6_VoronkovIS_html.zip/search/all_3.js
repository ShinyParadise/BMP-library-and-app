var searchData=
[
  ['downscale_16',['downscale',['../downscale_8cpp.html#ac272b4d4df2ef2162aa5cc322ee51ea8',1,'downscale(bmpFile *inBmp, short V, short H):&#160;downscale.cpp'],['../downscale_8h.html#ac272b4d4df2ef2162aa5cc322ee51ea8',1,'downscale(bmpFile *inBmp, short V, short H):&#160;downscale.cpp']]],
  ['downscale_2ecpp_17',['downscale.cpp',['../downscale_8cpp.html',1,'']]],
  ['downscale_2eh_18',['downscale.h',['../downscale_8h.html',1,'']]]
];
