var searchData=
[
  ['readbmp_73',['readBMP',['../file_handling_8cpp.html#a2c0d9713d8e52951869bfcbc82c97dc8',1,'readBMP(int num):&#160;fileHandling.cpp'],['../file_handling_8h.html#a2c0d9713d8e52951869bfcbc82c97dc8',1,'readBMP(int num):&#160;fileHandling.cpp']]],
  ['rotate_74',['rotate',['../rotate_8cpp.html#a7b6748a886717e5e4a35db20a4fcbc8d',1,'rotate(bmpFile *inBmp, short angle):&#160;rotate.cpp'],['../rotate_8h.html#a7b6748a886717e5e4a35db20a4fcbc8d',1,'rotate(bmpFile *inBmp, short angle):&#160;rotate.cpp']]]
];
