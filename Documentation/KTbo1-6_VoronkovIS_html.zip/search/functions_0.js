var searchData=
[
  ['bright_70',['bright',['../bright_8cpp.html#a47695a016157b8111fdf506c0af456f6',1,'bright(bmpFile *inBmp, short f):&#160;bright.cpp'],['../bright_8h.html#a47695a016157b8111fdf506c0af456f6',1,'bright(bmpFile *inBmp, short f):&#160;bright.cpp']]]
];
