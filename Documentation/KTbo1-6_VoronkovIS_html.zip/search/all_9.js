var searchData=
[
  ['readbmp_31',['readBMP',['../file_handling_8cpp.html#a2c0d9713d8e52951869bfcbc82c97dc8',1,'readBMP(int num):&#160;fileHandling.cpp'],['../file_handling_8h.html#a2c0d9713d8e52951869bfcbc82c97dc8',1,'readBMP(int num):&#160;fileHandling.cpp']]],
  ['reserved1_32',['Reserved1',['../structbmfh.html#a9ce3ee3eed878dbcdb448ffa8af238a4',1,'bmfh']]],
  ['reserved2_33',['Reserved2',['../structbmfh.html#aba83bc97869084ffb03211a71016ff04',1,'bmfh']]],
  ['rgbblue_34',['rgbBlue',['../structrgbq.html#a34d70d15d836828bd92ece15cf7242d1',1,'rgbq']]],
  ['rgbgreen_35',['rgbGreen',['../structrgbq.html#acda1183edf50eb439839e3a75c8b5549',1,'rgbq']]],
  ['rgbq_36',['rgbq',['../structrgbq.html',1,'']]],
  ['rgbred_37',['rgbRed',['../structrgbq.html#a2d6b70a30d7970c5452a624a5e38f3d2',1,'rgbq']]],
  ['rgbreserved_38',['rgbReserved',['../structrgbq.html#abedcb313f8bb8c0e13689c8f8850b6d0',1,'rgbq']]],
  ['rotate_39',['rotate',['../rotate_8cpp.html#a7b6748a886717e5e4a35db20a4fcbc8d',1,'rotate(bmpFile *inBmp, short angle):&#160;rotate.cpp'],['../rotate_8h.html#a7b6748a886717e5e4a35db20a4fcbc8d',1,'rotate(bmpFile *inBmp, short angle):&#160;rotate.cpp']]],
  ['rotate_2ecpp_40',['rotate.cpp',['../rotate_8cpp.html',1,'']]],
  ['rotate_2eh_41',['rotate.h',['../rotate_8h.html',1,'']]]
];
