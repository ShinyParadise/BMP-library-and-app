var searchData=
[
  ['upscale_46',['upscale',['../upscale_8cpp.html#a20422e796612cf7f3ae111eac1e3ed85',1,'upscale(bmpFile *inBmp, short V, short H):&#160;upscale.cpp'],['../upscale_8h.html#a20422e796612cf7f3ae111eac1e3ed85',1,'upscale(bmpFile *inBmp, short V, short H):&#160;upscale.cpp']]],
  ['upscale_2ecpp_47',['upscale.cpp',['../upscale_8cpp.html',1,'']]],
  ['upscale_2eh_48',['upscale.h',['../upscale_8h.html',1,'']]]
];
