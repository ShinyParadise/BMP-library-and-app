var searchData=
[
  ['imgmaxh_26',['imgMaxH',['../upscale_8cpp.html#a21e2ebfbac9947077b28a4cfe134a662',1,'upscale.cpp']]],
  ['imgmaxw_27',['imgMaxW',['../upscale_8cpp.html#a563e5fb82c22f2d4d43f81f2fa0f0b6d',1,'upscale.cpp']]]
];
