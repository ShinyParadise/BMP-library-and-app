var searchData=
[
  ['writebmp_77',['writeBMP',['../file_handling_8cpp.html#a45ea6d4cad7fa56883ecb360b3ec32dc',1,'writeBMP(int num, bmpFile *inBmp):&#160;fileHandling.cpp'],['../file_handling_8h.html#a45ea6d4cad7fa56883ecb360b3ec32dc',1,'writeBMP(int num, bmpFile *inBmp):&#160;fileHandling.cpp']]]
];
