var searchData=
[
  ['reserved1_91',['Reserved1',['../structbmfh.html#a9ce3ee3eed878dbcdb448ffa8af238a4',1,'bmfh']]],
  ['reserved2_92',['Reserved2',['../structbmfh.html#aba83bc97869084ffb03211a71016ff04',1,'bmfh']]],
  ['rgbblue_93',['rgbBlue',['../structrgbq.html#a34d70d15d836828bd92ece15cf7242d1',1,'rgbq']]],
  ['rgbgreen_94',['rgbGreen',['../structrgbq.html#acda1183edf50eb439839e3a75c8b5549',1,'rgbq']]],
  ['rgbred_95',['rgbRed',['../structrgbq.html#a2d6b70a30d7970c5452a624a5e38f3d2',1,'rgbq']]],
  ['rgbreserved_96',['rgbReserved',['../structrgbq.html#abedcb313f8bb8c0e13689c8f8850b6d0',1,'rgbq']]]
];
