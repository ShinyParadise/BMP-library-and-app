var searchData=
[
  ['bfsize_78',['bfSize',['../structbmfh.html#a99c44db833a458a7be8ddf4fe19f6ffa',1,'bmfh']]],
  ['bftype_79',['bfType',['../structbmfh.html#adaefa585a14767d74cdedb0e3ff6daa3',1,'bmfh']]],
  ['bisize_80',['biSize',['../structbmih.html#a4d826e11c94868cb46a04c376998c85e',1,'bmih']]],
  ['bitcount_81',['BitCount',['../structbmih.html#a9f2b08dbee672c9da1bd1f104124dbca',1,'bmih']]],
  ['bmfheader_82',['bmFHeader',['../structbmp_file.html#a9d4365b4c361b3ef5d994220fb484dd4',1,'bmpFile']]],
  ['bmiheader_83',['bmIHeader',['../structbmp_file.html#acaee65f96c0c723cbc6ca099dca1a9e1',1,'bmpFile']]]
];
