var searchData=
[
  ['upscale_2ecpp_68',['upscale.cpp',['../upscale_8cpp.html',1,'']]],
  ['upscale_2eh_69',['upscale.h',['../upscale_8h.html',1,'']]]
];
