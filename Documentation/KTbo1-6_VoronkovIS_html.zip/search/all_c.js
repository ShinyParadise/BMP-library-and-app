var searchData=
[
  ['width_49',['Width',['../structbmih.html#a35d635da4105b01b2d74f39622fc35f6',1,'bmih']]],
  ['writebmp_50',['writeBMP',['../file_handling_8cpp.html#a45ea6d4cad7fa56883ecb360b3ec32dc',1,'writeBMP(int num, bmpFile *inBmp):&#160;fileHandling.cpp'],['../file_handling_8h.html#a45ea6d4cad7fa56883ecb360b3ec32dc',1,'writeBMP(int num, bmpFile *inBmp):&#160;fileHandling.cpp']]]
];
