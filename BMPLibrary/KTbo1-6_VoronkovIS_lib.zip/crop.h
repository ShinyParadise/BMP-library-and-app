#pragma once
#include "structs.h"

void crop(int delta, bmpFile* inBmp);